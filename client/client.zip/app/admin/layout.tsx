import { ReactNode } from "react";
import SideBar from "@/components/admin/SideBar";

type LayoutProps = {
  children: ReactNode;
};

const Layout = ({ children }: LayoutProps) => {
  return <>
    <div>
       <div className="flex">
         <SideBar/>
         <div>
           {children}
         </div>
       </div>
    </div>
  </>;
};

export default Layout;