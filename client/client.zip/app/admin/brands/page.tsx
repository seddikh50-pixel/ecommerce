import React from 'react'

const page = () => {
  return (
    <div>band</div>
  )
}

export default page