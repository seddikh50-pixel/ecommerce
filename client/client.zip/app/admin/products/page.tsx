import React from 'react'

const page = () => {
  return (
    <div>products</div>
  )
}

export default page