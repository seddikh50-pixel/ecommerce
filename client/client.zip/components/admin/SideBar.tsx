import React from 'react'
import Link from 'next/link'
import { ChartBarStacked, Notebook, ShoppingBasket, ShoppingCart, Trello } from 'lucide-react'



const SideBar = () => {
  return (
    <div className='max-w-96 w-72 bg-gray-100 flex flex-col space-y-5 px-5 py-10'>
      <Link href={'/admin/products'} className='flex'><ShoppingCart/>Products</Link>
       <Link href={'/admin/caterories'} className='flex'><ChartBarStacked/> Category</Link>
       <Link href={'/admin/banners'} className='flex'><Notebook/> Banner</Link>
        <Link href={'/admin/brands'} className='flex'><Trello/> Brands</Link>
         <Link href={'/admin/orders'} className='flex'><ShoppingBasket/> Order</Link>
    </div>
  )
}

export default SideBar